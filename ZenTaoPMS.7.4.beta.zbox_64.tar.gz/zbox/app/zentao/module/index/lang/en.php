<?php
$lang->index->common = 'Index';
$lang->index->index  = 'Index';
