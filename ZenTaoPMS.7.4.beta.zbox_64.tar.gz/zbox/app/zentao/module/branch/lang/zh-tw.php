<?php
$lang->branch->common = '分支';
$lang->branch->manage = '分支管理';
$lang->branch->delete = '分支刪除';

$lang->branch->manageTitle = '%s管理';
$lang->branch->all         = '所有';

$lang->branch->confirmDelete = '%branch%刪除，會影響關聯該%branch%的需求、模組、計劃、發佈、Bug、用例等等，請慎重考慮。是否刪除該%branch%';
