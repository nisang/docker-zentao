$(document).ready()
{
    $('#password').focus();
}
