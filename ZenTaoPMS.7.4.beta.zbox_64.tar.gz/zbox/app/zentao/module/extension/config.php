<?php
$config->extension = new stdclass();
$config->extension->apiRoot   = 'http://api.zentao.net/extension-';
$config->extension->extPathes = array('module', 'bin', 'www', 'library', 'config');
