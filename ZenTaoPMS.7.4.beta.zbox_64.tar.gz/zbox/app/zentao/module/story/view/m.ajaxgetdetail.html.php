<div>
  <p><strong><?php echo $lang->story->spec?><strong></p>
  <?php echo $story->spec;?>
</div>
<div>
  <p><strong><?php echo $lang->story->verify?><strong></p>
  <?php echo $story->verify;?>
</div>
<?php include '../../common/view/m.action.html.php'?>
